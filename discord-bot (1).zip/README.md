# Basit Discord Bot

## Kurulum
1. Bu dizini klonlayın veya zip'i indirin.
2. \`.env\` dosyasını oluşturun ve \`.env.example\` içeriğini kopyalayın.
3. \`npm install\` ile bağımlılıkları yükleyin.
4. \`npm start\` komutuyla botu başlatın.

## Özellikler
- Web sunucu: UptimeRobot gibi servislerle 7/24 açık kalmak için basit bir ping endpointi var.
- Discord komutu: \`ping\` yazınca \`Pong! 🏓\` cevap verir.
