const { SlashCommandBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ping')
    .setDescription('Botun yanıt süresini gösterir.'),
  async execute(interaction) {
    const sent = await interaction.reply({ content: 'Pong!', fetchReply: true });
    const time = sent.createdTimestamp - interaction.createdTimestamp;
    await interaction.editReply(`Gecikme: ${time}ms`);
  }
};
